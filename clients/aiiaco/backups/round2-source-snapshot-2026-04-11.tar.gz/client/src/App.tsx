import { useEffect } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import StructuredData from "./seo/StructuredData";
import NoindexRoute from "./seo/NoindexRoute";

// Pages
import Home from "./pages/Home";
import ManifestoPage from "./pages/ManifestoPage";
import MethodPage from "./pages/MethodPage";
import IndustriesPage from "./pages/IndustriesPage";
import ModelsPage from "./pages/ModelsPage";
import CaseStudiesPage from "./pages/CaseStudiesPage";
import ResultsPage from "./pages/ResultsPage";
import UpgradePage from "./pages/UpgradePage";
import PrivacyPage from "./pages/PrivacyPage";
import TermsPage from "./pages/TermsPage";
import AIIntegrationPage from "./pages/AIIntegrationPage";
import AIImplementationPage from "./pages/AIImplementationPage";
import AIAutomationPage from "./pages/AIAutomationPage";
import AICrmIntegrationPage from "./pages/AICrmIntegrationPage";
import AIWorkflowAutomationPage from "./pages/AIWorkflowAutomationPage";
import AIRevenueEnginePage from "./pages/AIRevenueEnginePage";
import AIForRealEstatePage from "./pages/AIForRealEstatePage";
import AIForVacationRentalsPage from "./pages/AIForVacationRentalsPage";
import AIGovernancePage from "./pages/AIGovernancePage";
import WorkplacePage from "./pages/WorkplacePage";
import IndustryMicrosite from "./pages/IndustryMicrosite";
import AdminLeadsPage from "./pages/AdminLeadsPage";
import AdminConsolePage from "./pages/AdminConsolePage";
import AdminAgentPage from "./pages/AdminAgentPage";
import AdminKnowledgePage from "./pages/AdminKnowledgePage";
import AdminAnalyticsPage from "./pages/AdminAnalyticsPage";
import CorporatePage from "./pages/CorporatePage";
import AgentPackagePage from "./pages/AgentPackagePage";
import OperatorPage from "./pages/OperatorPage";
import DiagnosticDemoPage from "./pages/DiagnosticDemoPage";
import DemoWalkthroughPage from "./pages/DemoWalkthroughPage";
import TalkPage from "./pages/TalkPage";
import AiiAVoiceWidget from "./components/AiiAVoiceWidget";
import CookieConsent from "./components/CookieConsent";

// Client Portal Pages
import PortalAuth from "./pages/portal/PortalAuth";
import PortalDashboard from "./pages/portal/PortalDashboard";
import PortalAgent from "./pages/portal/PortalAgent";
import PortalConversations from "./pages/portal/PortalConversations";
import PortalEmbed from "./pages/portal/PortalEmbed";
import PortalBilling from "./pages/portal/PortalBilling";
import PortalSettings from "./pages/portal/PortalSettings";

// Immediate external redirect component - fires window.location.href on mount
// This is the reliable fallback in case the Express server redirect is bypassed
function VideoStudioRedirect() {
  useEffect(() => {
    window.location.href = "https://aiivideo-zyf9pqt6.manus.space";
  }, []);
  return null;
}

function Router() {
  // StructuredData is rendered here (inside the wouter Router context) so its
  // internal useLocation() call resolves correctly and matches SSR dispatch.
  return (
    <>
      <StructuredData />
      <Switch>
      <Route path="/" component={Home} />
      <Route path="/manifesto" component={ManifestoPage} />
      <Route path="/method" component={MethodPage} />
      <Route path="/industries" component={IndustriesPage} />
      <Route path="/models" component={ModelsPage} />
      <Route path="/case-studies" component={CaseStudiesPage} />
      <Route path="/results" component={ResultsPage} />
      <Route path="/upgrade" component={UpgradePage} />
      <Route path="/corporate" component={CorporatePage} />
      <Route path="/agentpackage" component={AgentPackagePage} />
      <Route path="/privacy" component={PrivacyPage} />
      <Route path="/terms" component={TermsPage} />
      <Route path="/ai-integration" component={AIIntegrationPage} />
      <Route path="/ai-implementation-services" component={AIImplementationPage} />
      <Route path="/ai-automation-for-business" component={AIAutomationPage} />
      <Route path="/ai-governance" component={AIGovernancePage} />
      <Route path="/ai-crm-integration" component={AICrmIntegrationPage} />
      <Route path="/ai-workflow-automation" component={AIWorkflowAutomationPage} />
      <Route path="/ai-revenue-engine" component={AIRevenueEnginePage} />
      <Route path="/ai-for-real-estate" component={AIForRealEstatePage} />
      <Route path="/ai-for-vacation-rentals" component={AIForVacationRentalsPage} />
      <Route path="/workplace" component={WorkplacePage} />
      <Route path="/industries/:slug" component={IndustryMicrosite} />
      {/* Admin routes - all noindex */}
      <Route path="/admin/leads">
        <NoindexRoute><AdminLeadsPage /></NoindexRoute>
      </Route>
      <Route path="/admin/agent">
        <NoindexRoute><AdminAgentPage /></NoindexRoute>
      </Route>
      <Route path="/admin/knowledge">
        <NoindexRoute><AdminKnowledgePage /></NoindexRoute>
      </Route>
      <Route path="/admin/analytics">
        <NoindexRoute><AdminAnalyticsPage /></NoindexRoute>
      </Route>
      <Route path="/admin-opsteam">
        <NoindexRoute><AdminConsolePage /></NoindexRoute>
      </Route>
      <Route path="/operator">
        <NoindexRoute><OperatorPage /></NoindexRoute>
      </Route>
      <Route path="/demo" component={DiagnosticDemoPage} />
      <Route path="/demo-walkthrough">
        <NoindexRoute><DemoWalkthroughPage /></NoindexRoute>
      </Route>
      {/* Client Portal - all noindex */}
      <Route path="/portal/login">
        <NoindexRoute><PortalAuth /></NoindexRoute>
      </Route>
      <Route path="/portal">
        <NoindexRoute><PortalDashboard /></NoindexRoute>
      </Route>
      <Route path="/portal/agent">
        <NoindexRoute><PortalAgent /></NoindexRoute>
      </Route>
      <Route path="/portal/conversations">
        <NoindexRoute><PortalConversations /></NoindexRoute>
      </Route>
      <Route path="/portal/embed">
        <NoindexRoute><PortalEmbed /></NoindexRoute>
      </Route>
      <Route path="/portal/billing">
        <NoindexRoute><PortalBilling /></NoindexRoute>
      </Route>
      <Route path="/portal/settings">
        <NoindexRoute><PortalSettings /></NoindexRoute>
      </Route>
      <Route path="/talk" component={TalkPage} />
      <Route path="/videostudio" component={VideoStudioRedirect} />
      {/* Final fallback - wouter Switch matches this when nothing else did, so any unknown URL renders NotFound */}
      <Route component={NotFound} />
    </Switch>
    </>
  );
}

function App() {
  // Signal to vite-plugin-prerender that the app is ready to snapshot
  useEffect(() => {
    document.dispatchEvent(new Event("prerender-ready"));
  }, []);

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          {/*
            Router owns client-side routing. StructuredData is rendered INSIDE Router
            (see Router() function) so that wouter's useLocation hook resolves against
            the same context that SSR uses via memoryLocation. This prevents a hydration
            mismatch between the SSR-injected JSON-LD and the client re-render.
          */}
          <Router />
          <AiiAVoiceWidget />
          <CookieConsent />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
