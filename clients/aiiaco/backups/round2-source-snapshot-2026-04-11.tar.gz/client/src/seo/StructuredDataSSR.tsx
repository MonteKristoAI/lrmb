/**
 * AiiAco Structured Data - SSR-safe version
 *
 * react-helmet-async v2 SSR: script children must be text nodes, NOT dangerouslySetInnerHTML.
 *
 * IMPORTANT: This component takes pathname as a PROP, not via useLocation(), because
 * during renderToString the wouter Router's memoryLocation hook is only available inside
 * the Router tree - reading useLocation() outside the Router falls back to the browser
 * location hook, which throws on the server. Passing pathname explicitly decouples this
 * component from the wouter Router and makes it safe to render anywhere in the tree.
 *
 * The global Organization, WebSite, ProfessionalService, and Person schemas are defined
 * in the STATIC HTML shell (client/index.html). They are global and identical across
 * every page, so this component only injects PAGE-SPECIFIC schema based on the route:
 * - BreadcrumbList on non-homepage pages
 * - HowTo on /method
 * - FAQPage on pages with FAQ sections (ai-integration, ai-automation-for-business, plus new service pages)
 * - AboutPage on /manifesto
 */
import { Helmet } from "react-helmet-async";

const BASE_URL = "https://aiiaco.com";

// Slug tokens that should be rendered in uppercase/specific casing in breadcrumb labels.
// Extend this list as new routes are added.
const UPPER_TOKENS: Record<string, string> = {
  ai: "AI",
  crm: "CRM",
  ev: "EV",
  b2b: "B2B",
  b2c: "B2C",
  saas: "SaaS",
};

function titleCaseSegment(segment: string): string {
  return segment
    .split("-")
    .map(word => {
      const lower = word.toLowerCase();
      if (UPPER_TOKENS[lower]) return UPPER_TOKENS[lower];
      return word.charAt(0).toUpperCase() + word.slice(1);
    })
    .join(" ");
}

type SchemaInput = Record<string, unknown>;

function buildBreadcrumb(pathname: string): SchemaInput | null {
  if (pathname === "/" || pathname === "") return null;
  const segments = pathname.split("/").filter(Boolean);
  const items: Array<Record<string, unknown>> = [
    {
      "@type": "ListItem",
      position: 1,
      name: "Home",
      item: `${BASE_URL}/`,
    },
  ];
  let acc = "";
  segments.forEach((segment, idx) => {
    acc += `/${segment}`;
    items.push({
      "@type": "ListItem",
      position: idx + 2,
      name: titleCaseSegment(segment),
      item: `${BASE_URL}${acc}`,
    });
  });
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "@id": `${BASE_URL}${pathname}#breadcrumb`,
    itemListElement: items,
  };
}

function buildHowToMethod(): SchemaInput {
  return {
    "@context": "https://schema.org",
    "@type": "HowTo",
    "@id": `${BASE_URL}/method#howto`,
    name: "How AiiAco Deploys AI Integration: The 4-Phase Method",
    description:
      "AiiAco's operational AI integration method follows four phases to eliminate friction and deploy measurable AI infrastructure across a business.",
    totalTime: "PT4W",
    step: [
      {
        "@type": "HowToStep",
        position: 1,
        name: "Find the Friction",
        text: "Process mapping, bottleneck identification, coordination audit, and data reliability checks across all departments. AiiAco maps how work actually flows through the business, where tasks wait on people, where admins chase updates, and where coordination is consuming margin.",
      },
      {
        "@type": "HowToStep",
        position: 2,
        name: "Implement the Fix",
        text: "Deploy workflow automation, CRM reactivation systems, and outreach automation. Implementation of practical AI systems that eliminate the specific friction points identified in the audit phase.",
      },
      {
        "@type": "HowToStep",
        position: 3,
        name: "Measure the Improvement",
        text: "Build real-time dashboards, establish execution speed metrics, and create revenue visibility reporting. Every module is measured against KPIs defined before implementation begins.",
      },
      {
        "@type": "HowToStep",
        position: 4,
        name: "Expand What Works",
        text: "Cross-department rollout of proven modules, playbook documentation, and team training. Scale the systems that demonstrate measurable results across the entire business.",
      },
    ],
  };
}

function buildFaqAiIntegration(): SchemaInput {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "@id": `${BASE_URL}/ai-integration#faq`,
    mainEntity: [
      {
        "@type": "Question",
        name: "What is AI integration and how is it different from buying AI tools?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "AI integration embeds artificial intelligence into business operations as functional infrastructure, not a tool layer. Buying AI tools means subscribing to standalone software like ChatGPT. AI integration establishes an operational layer that handles repeatable decisions, automates complex workflows, surfaces intelligence from data, and scales execution without proportional headcount growth. AiiAco designs, deploys, and manages this operational system on your behalf.",
        },
      },
      {
        "@type": "Question",
        name: "How long does AI integration take for a mid-size business?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "Most operational modules are implemented within 2 to 4 weeks. A full AI integration engagement runs 4 to 9 weeks depending on the number of departments, existing system complexity, and integration scope. AiiAco follows a four-phase framework: Diagnostic Architecture, Integration Blueprint, Managed Deployment, and Continuous Optimization.",
        },
      },
      {
        "@type": "Question",
        name: "How does AI integration work with existing CRM systems?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "AiiAco integrates AI directly into existing CRM and ERP infrastructure without requiring platform migration. The integration layer sits above existing systems, automating data entry, triggering outreach sequences, surfacing pipeline intelligence, and reactivating dormant contact databases. No replacement of existing software is required in most engagements.",
        },
      },
      {
        "@type": "Question",
        name: "What is performance-based AI integration?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "Performance-based AI integration ties AiiAco's compensation directly to measurable client outcomes rather than billable hours or project milestones. Fees are structured against defined KPIs established at the start of each engagement, such as cycle time reduction, conversion rate improvement, or headcount efficiency gains.",
        },
      },
    ],
  };
}

function buildFaqAiCrmIntegration(): SchemaInput {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "@id": `${BASE_URL}/ai-crm-integration#faq`,
    mainEntity: [
      {
        "@type": "Question",
        name: "How do you integrate AI into a CRM?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "AiiAco integrates AI into a CRM in four steps: map the current workflow, design an AI integration layer that matches specific friction points, deploy the layer via native APIs and webhooks, and manage it on an ongoing basis. The existing CRM is not replaced or migrated. Lead scoring, document extraction, conversational qualification, outbound sequence generation, and predictive pipeline intelligence all run as operational layers on top of Salesforce, HubSpot, Pipedrive, GoHighLevel, or whatever platform the client already uses.",
        },
      },
      {
        "@type": "Question",
        name: "Which CRMs does AiiAco work with?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "AiiAco integrates with Salesforce, HubSpot, Pipedrive, GoHighLevel, Follow Up Boss, Zoho CRM, Microsoft Dynamics 365, Close, Copper, Keap, ActiveCampaign, and industry-specific platforms like kvCORE (real estate), Encompass (mortgage), Kantata (consulting). For any platform with a documented API, AiiAco can build a custom integration layer.",
        },
      },
      {
        "@type": "Question",
        name: "Do we have to migrate off our current CRM?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "No. AiiAco integrates with the CRM you already use. The AI layer sits above the CRM via APIs and webhooks. Your admins keep their existing workflows, reports, and dashboards. The AI automation runs alongside them, replacing manual coordination work without disrupting day-to-day operations.",
        },
      },
    ],
  };
}

function buildFaqAiWorkflowAutomation(): SchemaInput {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "@id": `${BASE_URL}/ai-workflow-automation#faq`,
    mainEntity: [
      {
        "@type": "Question",
        name: "How does AI automate business operations?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "AI automates business operations by replacing manual, repetitive, and decision-based tasks with systems that execute faster and more consistently than human workflows. It handles document processing, lead qualification, customer communication, pipeline tracking, and routine decision-making across revenue and operational functions.",
        },
      },
      {
        "@type": "Question",
        name: "What operational tasks can AI automate immediately?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "The fastest-to-deploy automations include lead qualification and routing, document extraction from PDFs and images, customer outreach sequences, CRM data entry, pipeline status updates, report generation, and inbox triage. These typically deploy within 2 to 4 weeks per workflow. Deeper automation across multiple departments takes 8 to 14 weeks.",
        },
      },
      {
        "@type": "Question",
        name: "What is the difference between AI workflow automation and RPA?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "RPA automates deterministic, rule-based tasks: clicking buttons, copying data, filling forms. AI workflow automation handles the decision-based and language-based work RPA cannot: reading and classifying documents, drafting communication, qualifying leads by intent, predicting outcomes, and adapting to new patterns.",
        },
      },
    ],
  };
}

function buildFaqAiRevenueEngine(): SchemaInput {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "@id": `${BASE_URL}/ai-revenue-engine#faq`,
    mainEntity: [
      {
        "@type": "Question",
        name: "What is an AI revenue system?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "An AI revenue system is a connected set of AI-powered workflows that generate, qualify, nurture, convert, and reactivate pipeline without proportional human effort. It sits across the five revenue functions (lead generation, nurture, pipeline intelligence, dormant database reactivation, and closed-loop attribution) and replaces the manual coordination work that consumes sales and marketing time.",
        },
      },
      {
        "@type": "Question",
        name: "How much revenue can an AI revenue system generate from a dormant customer database?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "Most CRMs carry 50 to 80 percent of contacts that have gone cold. A well-architected reactivation layer typically converts 15 to 25 percent of those into re-engaged responders, and a single-digit percentage back into active pipeline. For a brokerage, consultancy, or SaaS company with 10,000 dormant contacts, that translates to 100 to 500 new active opportunities without adding headcount or ad spend.",
        },
      },
      {
        "@type": "Question",
        name: "How long does AiiAco take to deploy an AI revenue system?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "The first operational module (usually either inbound lead scoring or dormant database reactivation) ships in 3 to 5 weeks. A full five-component AI revenue system running across lead gen, nurture, pipeline intelligence, reactivation, and attribution takes 8 to 14 weeks depending on CRM complexity, data quality, and the number of channels in use.",
        },
      },
    ],
  };
}

function buildFaqAiForRealEstate(): SchemaInput {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "@id": `${BASE_URL}/ai-for-real-estate#faq`,
    mainEntity: [
      {
        "@type": "Question",
        name: "How does AI help real estate brokerages?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "AI for real estate brokerages embeds artificial intelligence into lead qualification, listing content generation, transaction coordination, and agent productivity workflows. It replaces manual follow-up with multi-touch sequences, generates MLS-compliant listing copy in seconds, and surfaces deal intelligence for brokers managing dozens of agents.",
        },
      },
      {
        "@type": "Question",
        name: "Does AI replace real estate agents?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "No. AI replaces the coordination and administrative work that consumes agent time: lead qualification, follow-up scheduling, content drafting, reporting, and transaction tracking. Agents keep the judgment work: client relationships, negotiations, showings, deal structuring. Brokerages that deploy AI typically see agent capacity increase 2 to 3 times without hiring.",
        },
      },
      {
        "@type": "Question",
        name: "Can AI write MLS listings without violating Fair Housing Act rules?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "Yes. AiiAco deploys content generation systems with Fair Housing Act language filters and NAR advertising compliance built in. Listing descriptions adhere to protected-class language rules and can be reviewed by compliance officers before publication.",
        },
      },
    ],
  };
}

function buildFaqAiForVacationRentals(): SchemaInput {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "@id": `${BASE_URL}/ai-for-vacation-rentals#faq`,
    mainEntity: [
      {
        "@type": "Question",
        name: "What does AI do for a vacation rental operator?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "AI handles the repeatable coordination work that consumes operator time: guest messaging across every channel, maintenance dispatch to field teams, pricing adjustments based on occupancy signals, review analysis, owner financial reporting, and new unit onboarding. Operators keep the judgment work: owner relationships, guest escalations, strategic pricing calls, and property acquisition.",
        },
      },
      {
        "@type": "Question",
        name: "Isn't Hostaway, Hospitable, or Jurny already an AI vacation rental platform?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "Yes, and AiiAco works with them, not against them. Hostaway, Hospitable, Jurny, RentalReady, and Boom are product platforms that handle specific parts of vacation rental operations. AiiAco is an integration layer that ties those platforms together and adds AI coordination between them.",
        },
      },
      {
        "@type": "Question",
        name: "How long does AI integration take for a vacation rental operator?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "A focused guest communication deployment takes 3 to 5 weeks. Full integration across guest comms, maintenance dispatch, pricing, review analysis, and financial reporting runs 6 to 12 weeks depending on unit count and PMS complexity.",
        },
      },
    ],
  };
}

function buildFaqAiAutomation(): SchemaInput {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "@id": `${BASE_URL}/ai-automation-for-business#faq`,
    mainEntity: [
      {
        "@type": "Question",
        name: "How does AI automate business operations?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "AI automates business operations by replacing manual, repetitive, and decision-based tasks with systems that execute faster and more consistently than human workflows. It handles document processing, lead qualification, customer communication, pipeline tracking, and routine decision-making across revenue and operational functions.",
        },
      },
      {
        "@type": "Question",
        name: "What operational tasks can AI automate immediately?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "The fastest-to-deploy AI automations include lead qualification and routing, document extraction from PDFs and images, customer outreach sequences, CRM data entry, pipeline status updates, report generation, and inbox triage. These typically deploy within 2 to 4 weeks per workflow.",
        },
      },
      {
        "@type": "Question",
        name: "How much does AI automation cost for a mid-market business?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "Engagement structures vary. AiiAco offers three models: a fixed-fee Strategic Blueprint for diagnostic and architecture, a structured retainer for Full Integration including deployment and managed optimization, and Performance Partnership with reduced upfront cost and milestone-based fees tied to defined outcomes.",
        },
      },
    ],
  };
}

function buildAboutPageManifesto(): SchemaInput {
  return {
    "@context": "https://schema.org",
    "@type": "AboutPage",
    "@id": `${BASE_URL}/manifesto#webpage`,
    name: "The Corporate Age of AI - AiiAco Manifesto",
    url: `${BASE_URL}/manifesto`,
    description:
      "AiiAco's operating principles for enterprise AI integration: why intelligence is infrastructure, why the window for first-mover advantage is closing, and why execution matters more than strategy.",
    about: { "@id": `${BASE_URL}/#organization` },
    author: { "@id": `${BASE_URL}/#nemr-hallak` },
    isPartOf: { "@id": `${BASE_URL}/#website` },
  };
}

type StructuredDataSSRProps = {
  pathname: string;
};

export default function StructuredDataSSR({ pathname }: StructuredDataSSRProps) {
  // Normalize: strip trailing slash except for root
  const normalized = pathname.length > 1 && pathname.endsWith("/")
    ? pathname.slice(0, -1)
    : pathname;

  const schemas: SchemaInput[] = [];

  const breadcrumb = buildBreadcrumb(normalized);
  if (breadcrumb) schemas.push(breadcrumb);

  if (normalized === "/method") {
    schemas.push(buildHowToMethod());
  }

  if (normalized === "/ai-integration") {
    schemas.push(buildFaqAiIntegration());
  }

  if (normalized === "/ai-automation-for-business") {
    schemas.push(buildFaqAiAutomation());
  }

  if (normalized === "/ai-crm-integration") {
    schemas.push(buildFaqAiCrmIntegration());
  }

  if (normalized === "/ai-workflow-automation") {
    schemas.push(buildFaqAiWorkflowAutomation());
  }

  if (normalized === "/ai-revenue-engine") {
    schemas.push(buildFaqAiRevenueEngine());
  }

  if (normalized === "/ai-for-real-estate") {
    schemas.push(buildFaqAiForRealEstate());
  }

  if (normalized === "/ai-for-vacation-rentals") {
    schemas.push(buildFaqAiForVacationRentals());
  }

  if (normalized === "/manifesto") {
    schemas.push(buildAboutPageManifesto());
  }

  if (schemas.length === 0) return null;

  return (
    <Helmet>
      {schemas.map((schema, i) => (
        <script key={i} type="application/ld+json">
          {JSON.stringify(schema)}
        </script>
      ))}
    </Helmet>
  );
}
