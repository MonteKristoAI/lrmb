/*
 * AiiAco SEO Configuration
 * Central source of truth for all meta tags, OG, and structured data
 */

export const SITE = {
  name: "AiiAco",
  domain: "https://aiiaco.com",
  defaultTitle: "AiiAco | AI Integration Company for Real Estate, Mortgage & Management Consulting",
  defaultDescription:
    "AiiAco is an enterprise AI integration company. We design, deploy, and manage operational AI systems for real estate, mortgage lending, and management consulting firms. Done-for-you, performance-based.",
  ogImage:
    "https://d2xsxph8kpxj0f.cloudfront.net/310419663031409823/jiUKWZNCEesKEKgdJkoZwj/aiia-og-image-v3_1b0f8ae3.png",
  twitterHandle: "@aiiaco",
  keywords:
    "AI integration, enterprise AI integration, AI integration company, AI revenue systems, AI CRM integration, AI workflow automation, managed AI integration, operational AI infrastructure, AI workforce, done-for-you AI, performance-based AI, AI for real estate, AI for vacation rentals, AI for property management, AI integration authority",
};

export const PAGE_META: Record<string, { title: string; description: string }> = {
  "/": {
    title: "AiiAco | AI Integration Company for Real Estate, Mortgage & Management Consulting",
    description:
      "AiiAco is an enterprise AI integration company. We design, deploy, and manage operational AI systems for real estate, mortgage lending, and management consulting firms. Done-for-you, performance-based.",
  },
  "/manifesto": {
    title: "The Corporate Age of AI | AiiAco Manifesto",
    description:
      "AI is no longer a tool - it is infrastructure. Read the AiiAco manifesto on operational AI integration and the next corporate evolution, by founder Nemr Hallak.",
  },
  "/method": {
    title: "AI Integration Method | 4-Phase Operational Framework",
    description:
      "AiiAco's 4-phase AI integration method: Find the Friction, Implement the Fix, Measure the Improvement, and Expand What Works. A disciplined framework for enterprise AI deployment.",
  },
  "/industries": {
    title: "AI Integration by Industry | Real Estate, Mortgage, Hospitality, Consulting",
    description:
      "Operational AI integration for real estate brokerages, mortgage lenders, commercial property managers, luxury hospitality operators, financial services firms, and management consultancies.",
  },
  "/models": {
    title: "Engagement Models | Strategic Blueprint, Full Integration, Performance Partnership",
    description:
      "Three ways to work with AiiAco: Strategic Blueprint (diagnostic + architecture), Full Integration (end-to-end managed deployment), or Performance Partnership (milestone-based, outcome-aligned fees).",
  },
  "/case-studies": {
    title: "AI Integration Case Studies | Measured Operational Outcomes",
    description:
      "Structured AI integration outcomes across real estate, mortgage lending, commercial property, and management consulting. 66% cycle time reduction, 3x capacity, 75% document processing reduction.",
  },
  "/results": {
    title: "AI Integration Results | Outcomes Engineered, Not Promised",
    description:
      "Measurable outcomes from AiiAco AI integration engagements: cycle time reduction, capacity increase, automation coverage, and operational visibility across 20+ industries.",
  },
  "/upgrade": {
    title: "Initiate AI Upgrade | Book Your AiiAco Engagement",
    description:
      "Begin your AI integration engagement. Submit a structured intake or book a strategy call. AiiAco responds within 24 hours with a direct, scenario-specific plan.",
  },
  "/privacy": {
    title: "Privacy Policy | AiiAco",
    description:
      "AiiAco privacy policy - how we collect, use, and protect your information across our website and engagement services.",
  },
  "/terms": {
    title: "Terms of Service | AiiAco",
    description:
      "AiiAco terms of service governing use of our platform, website, and engagement services.",
  },
  "/ai-integration": {
    title: "AI Integration Services for Enterprise | AiiAco",
    description:
      "AI integration embeds artificial intelligence into business operations as functional infrastructure. AiiAco designs, deploys, and manages this infrastructure for mid-market and enterprise businesses.",
  },
  "/ai-implementation-services": {
    title: "AI Implementation Services | Managed Deployment & Integration",
    description:
      "End-to-end AI implementation services: diagnostic audit, integration architecture, deployment, and managed optimization. AiiAco runs the full stack so your team receives outcomes, not workload.",
  },
  "/ai-automation-for-business": {
    title: "AI Automation for Business | Operational Automation at Scale",
    description:
      "AI automation for business replaces manual, repetitive, and decision-based tasks with systems that execute faster and more accurately than human workflows. AiiAco deploys the infrastructure.",
  },
  "/ai-governance": {
    title: "AI Governance | Compliance, Oversight & Control Frameworks",
    description:
      "AiiAco AI governance frameworks: policy, compliance, audit trails, exception handling, and oversight controls built into every integration from day one, not added later.",
  },
  "/ai-crm-integration": {
    title: "AI CRM Integration | How to Integrate AI Into Your CRM",
    description:
      "AiiAco embeds AI directly into Salesforce, HubSpot, Pipedrive, GoHighLevel, and every major CRM in market. Lead scoring, document extraction, outbound sequences, and pipeline intelligence, deployed on top of the CRM you already own.",
  },
  "/ai-workflow-automation": {
    title: "AI Workflow Automation | How AI Automates Operations",
    description:
      "AiiAco builds AI workflow automation across revenue, client, document, financial, workforce, and operational infrastructure. Replaces manual coordination with AI systems that run continuously, measured against defined KPIs.",
  },
  "/ai-revenue-engine": {
    title: "AI Revenue Engine | AI Revenue Systems for Pipeline Without Headcount",
    description:
      "An AI revenue system is a connected set of AI-powered workflows that generate, qualify, nurture, convert, and reactivate pipeline without proportional human effort. AiiAco builds the full stack on top of your existing CRM.",
  },
  "/ai-for-real-estate": {
    title: "AI for Real Estate Brokerages | Lead Qualification, Listing Content, Pipeline AI",
    description:
      "AiiAco deploys AI lead qualification, MLS-compliant listing content, and pipeline intelligence for real estate brokerages. Built on top of Follow Up Boss, kvCORE, BoomTown, Lofty, and every major brokerage CRM.",
  },
  "/ai-for-vacation-rentals": {
    title: "AI for Vacation Rentals | Scale 50 to 500+ Units Without Headcount",
    description:
      "AiiAco is the integration layer for vacation rental operators on Hostaway, Guesty, Hospitable, or Hostfully. AI guest communication, maintenance coordination, review intelligence, and owner reporting, without replacing your stack.",
  },
  "/workplace": {
    title: "AiiAco Workplace | AI Integration for Service Businesses with Field Teams",
    description:
      "Operational AI integration for service businesses with field teams: mobile-first workflows, admin reduction, real-time coordination visibility, and dormant database reactivation.",
  },
  "/corporate": {
    title: "AiiAco for Corporate | Enterprise AI Integration Partner",
    description:
      "AiiAco is the enterprise AI integration partner for the corporate age. Complete operational AI infrastructure, delivered, managed, and performance-aligned.",
  },
  "/agentpackage": {
    title: "Agent Package | AI Tools Your Team Operates",
    description:
      "The AiiAco Agent Package: AI tools configured, deployed, and ready for your team to operate. Done-for-you setup with performance tracking and ongoing optimization.",
  },
  "/demo": {
    title: "Diagnostic Intelligence Demo | Voice AI Agents for Your Website",
    description:
      "See AiiAco's Diagnostic Intelligence in action: voice AI agents that live on your website, diagnose visitor needs through natural conversation, and automate booking and lead routing.",
  },
  "/talk": {
    title: "Talk to AiA | Voice AI Consultation",
    description:
      "Talk to AiA, AiiAco's voice AI assistant. Get immediate answers about AI integration for your business, engagement models, and implementation timelines.",
  },
};

/*
 * Industry microsite meta helper.
 * Called by IndustryMicrosite.tsx to build per-industry title/description dynamically.
 */
export function buildIndustryMeta(slug: string, industryName: string): {
  title: string;
  description: string;
} {
  return {
    title: `AI Integration for ${industryName} | AiiAco`,
    description: `Operational AI integration for ${industryName}. AiiAco designs, deploys, and manages AI systems that eliminate friction, automate workflows, and unlock measurable throughput without adding headcount.`,
  };
}
